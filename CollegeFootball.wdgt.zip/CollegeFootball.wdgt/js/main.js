require(["./ui", "./widget"], function (ui) {
    ui.load();
});
